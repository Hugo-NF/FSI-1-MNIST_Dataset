# Fundamentos de Sistemas Inteligentes - Projeto 1: MNIST Dataset
Projeto 1 da disciplina de Fundamentos de Sistemas Inteligentes - 2019.1, professor Díbio.

O projeto consiste em realizar experimentos de classificação com os algoritmos LDA e K-nn. 
Os dados a serem classificados são do "MNIST dataset" que consistem em 70.000 imagens de 
digitos manuscritos.

Mais detalhes no arquivo: docs/plano-ens-fsinteligentes-1-2019.pdf


#### Participantes
| Nome                      | Matrícula  |
|---------------------------|------------|
| Hugo Nascimento Fonseca   | 16/0008166 |
| José Luiz Gomes Nogueira  | 16/0032458 |
 

O relatório deste projeto, exibindo os resultados e análises encontra-se dentro em: docs/FSI_1_160032458_160008166.pdf
